package org.serverless.aws.put;

import lombok.Data;

@Data
public class PutInput {

    private String nombre;
    private String email;

}
