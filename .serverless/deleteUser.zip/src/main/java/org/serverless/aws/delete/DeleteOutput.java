package org.serverless.aws.delete;

import lombok.Data;
import lombok.AllArgsConstructor;

@Data
@AllArgsConstructor
public class DeleteOutput {
    private String mensaje;
}